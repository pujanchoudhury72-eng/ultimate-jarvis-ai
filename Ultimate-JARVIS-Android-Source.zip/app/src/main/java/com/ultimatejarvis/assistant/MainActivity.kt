package com.ultimatejarvis.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val executor = Executors.newSingleThreadExecutor()
    private val baseUrl = "https://ultimate-jarvis-ai.onrender.com"
    private var sessionToken: String? = null
    private var tts: TextToSpeech? = null
    private var recognizer: android.speech.SpeechRecognizer? = null
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var micButton: Button
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        checkBackend()
        askPassword()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 12)
            setBackgroundColor(0xFF0B1220.toInt())
        }
        val title = TextView(this).apply {
            text = "◉  ULTIMATE JARVIS"
            textSize = 23f
            setTextColor(0xFF69F0AE.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 8, 4, 4)
        }
        status = TextView(this).apply {
            text = "Connecting to your JARVIS backend…"
            textSize = 13f
            setTextColor(0xFFB0BEC5.toInt())
            setPadding(4, 4, 4, 10)
        }
        transcript = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            addView(transcript)
            isFillViewport = true
        }
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val apps = Button(this).apply { text = "Open YouTube"; setOnClickListener { openAppOrWeb("com.google.android.youtube", "https://youtube.com") } }
        val maps = Button(this).apply { text = "Maps"; setOnClickListener { openAppOrWeb("com.google.android.apps.maps", "https://maps.google.com") } }
        quick.addView(apps, LinearLayout.LayoutParams(0, -2, 1f))
        quick.addView(maps, LinearLayout.LayoutParams(0, -2, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "JARVIS ko command do…"
            setHintTextColor(0xFF90A4AE.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setSingleLine(false)
            minLines = 1
            maxLines = 3
            setBackgroundColor(0xFF172235.toInt())
            setPadding(12, 8, 12, 8)
        }
        micButton = Button(this).apply {
            text = "🎙️"
            contentDescription = "Speak to JARVIS"
            setOnClickListener { startListening() }
        }
        val send = Button(this).apply {
            text = "Send"
            setOnClickListener {
                val message = input.text.toString().trim()
                if (message.isNotEmpty()) {
                    input.setText("")
                    handleCommand(message)
                    (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                        .hideSoftInputFromWindow(input.windowToken, 0)
                }
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(micButton)
        row.addView(send)
        val note = TextView(this).apply {
            text = "Push-to-talk • Hindi/Hinglish • Phone actions need Android support. Wake-word listening is not enabled."
            textSize = 11f
            setTextColor(0xFF90A4AE.toInt())
            setPadding(4, 8, 4, 0)
        }
        root.addView(title)
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(quick)
        root.addView(row)
        root.addView(note)
        setContentView(root)
        addBubble("JARVIS", "Namaste! Main JARVIS hoon. Mic dabao ya command type karo. Pehli baar online AI use karne ke liye backend password chahiye.")
    }

    private fun addBubble(who: String, text: String) {
        runOnUiThread {
            val tv = TextView(this).apply {
                this.text = "$who\n$text"
                textSize = 15f
                setTextColor(if (who == "JARVIS") 0xFFE8F5E9.toInt() else 0xFFFFFFFF.toInt())
                setBackgroundColor(if (who == "JARVIS") 0xFF152B2A.toInt() else 0xFF1B2940.toInt())
                setPadding(12, 10, 12, 10)
            }
            val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) }
            transcript.addView(tv, lp)
        }
    }

    private fun checkBackend() {
        executor.execute {
            try {
                val c = (URL("$baseUrl/api/health").openConnection() as HttpURLConnection)
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val code = c.responseCode
                c.disconnect()
                runOnUiThread { status.text = if (code in 200..299) "Backend connected • AI key configuration may still be required" else "Backend responded with HTTP $code" }
            } catch (_: Exception) {
                runOnUiThread { status.text = "Backend check failed • check internet connection" }
            }
        }
    }

    private fun askPassword() {
        val field = EditText(this).apply {
            hint = "APP_PASSWORD (Render mein configured)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("Connect to JARVIS")
            .setMessage("Apne JARVIS server ka APP_PASSWORD enter karo. Password sirf is app session mein use hoga; ise yahan chat mein share mat karna.")
            .setView(field)
            .setCancelable(false)
            .setPositiveButton("Connect") { _, _ -> login(field.text.toString()) }
            .setNegativeButton("Later") { _, _ -> status.text = "Offline/local commands available • AI login pending" }
            .show()
    }

    private fun login(password: String) {
        if (password.isBlank()) {
            status.text = "Password blank hai. Online AI connect nahi hua."
            return
        }
        status.text = "Signing in…"
        executor.execute {
            try {
                val result = postJson("/api/session", JSONObject().put("password", password), null)
                val token = result.optString("token",
                    result.optString("sessionToken", result.optString("accessToken", "")))
                if (token.isBlank()) throw Exception(result.optString("error", "Session token response mein nahi mila"))
                sessionToken = token
                runOnUiThread { status.text = "JARVIS online session connected" }
                addBubble("JARVIS", "Server se session connect ho gaya. Ab tum apne sawaal pooch sakte ho.")
                speak("JARVIS online hai")
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Login failed: ${e.message ?: "unknown error"}"
                    AlertDialog.Builder(this).setTitle("Login failed")
                        .setMessage("Password ya server response check karo. Password ko dobara try kar sakte ho.")
                        .setPositiveButton("Retry") { _, _ -> askPassword() }
                        .setNegativeButton("Continue offline", null).show()
                }
            }
        }
    }

    private fun postJson(path: String, body: JSONObject, token: String?): JSONObject {
        val conn = (URL("$baseUrl$path").openConnection() as HttpURLConnection)
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 45000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (!token.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer $token")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val json = try { JSONObject(text) } catch (_: Exception) { JSONObject().put("raw", text) }
            if (code !in 200..299) throw Exception(json.optString("error", json.optString("message", "HTTP $code")))
            return json
        } finally { conn.disconnect() }
    }

    private fun handleCommand(raw: String) {
        val cmd = raw.trim()
        addBubble("YOU", cmd)
        val lower = cmd.lowercase(Locale.ROOT)

        when {
            lower.contains("youtube") && (lower.contains("kholo") || lower.contains("open") || lower.contains("chala")) -> {
                replyAndSpeak("YouTube khol raha hoon.")
                openAppOrWeb("com.google.android.youtube", "https://youtube.com")
            }
            (lower.contains("chrome") || lower.contains("browser")) && (lower.contains("kholo") || lower.contains("open")) -> {
                replyAndSpeak("Browser khol raha hoon.")
                openAppOrWeb("com.android.chrome", "https://google.com")
            }
            lower.contains("maps") && (lower.contains("kholo") || lower.contains("open")) -> {
                replyAndSpeak("Maps khol raha hoon.")
                openAppOrWeb("com.google.android.apps.maps", "https://maps.google.com")
            }
            (lower.contains("google par search") || lower.startsWith("search ")) -> {
                val q = cmd.substringAfter("search ", cmd.substringAfter("Google par search", "")).trim()
                val query = if (q.isBlank()) cmd else q
                replyAndSpeak("Internet par search kar raha hoon.")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
            }
            lower.contains("settings") && (lower.contains("kholo") || lower.contains("open")) -> {
                replyAndSpeak("Phone settings khol raha hoon.")
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            }
            lower.contains("call ") || lower.contains("phone karo") || lower.contains("call karo") -> confirmAction(
                "Call action", "Dialer kholun? Number ya contact tum dialer mein confirm kar sakte ho.",
                { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:"))) })
            lower.contains("whatsapp") || lower.contains("message bhejo") || lower.contains("sms bhejo") -> confirmAction(
                "Message action", "Messaging app kholun? Message tum review karke khud send karoge.",
                { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))) })
            lower.contains("remind") || lower.contains("yaad dilana") || lower.contains("reminder") -> {
                replyAndSpeak("Reminder command note kar li. Is basic version mein reliable scheduled notifications abhi wired nahi hain; main tumhe Calendar ya reminder app kholne mein madad kar sakta hoon.")
                try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR)) }
                catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://calendar.google.com"))) }
            }
            else -> sendToAI(cmd)
        }
    }

    private fun sendToAI(message: String) {
        val token = sessionToken
        if (token.isNullOrBlank()) {
            replyAndSpeak("Online AI ke liye JARVIS server se connect karna hoga. Connect button ya app restart karke password enter karo.")
            return
        }
        status.text = "JARVIS soch raha hai…"
        executor.execute {
            try {
                val payload = JSONObject()
                    .put("message", message)
                    .put("history", JSONArray())
                val result = postJson("/api/chat", payload, token)
                val answer = listOf("reply", "response", "answer", "message", "content")
                    .map { result.optString(it, "") }.firstOrNull { it.isNotBlank() }
                    ?: "Server ka response mila, lekin answer field samajh nahi aayi: ${result}"
                runOnUiThread { status.text = "Ready" }
                replyAndSpeak(answer)
            } catch (e: Exception) {
                runOnUiThread { status.text = "AI request failed • ${e.message ?: "unknown error"}" }
                replyAndSpeak("Online AI se connect nahi ho paaya. Backend API settings aur server logs check karne honge.")
            }
        }
    }

    private fun confirmAction(title: String, message: String, action: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Continue") { _, _ ->
                try { action() } catch (_: Exception) { replyAndSpeak("Is action ke liye suitable app nahi mili.") }
            }.show()
    }

    private fun openAppOrWeb(packageName: String, url: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        try {
            if (launch != null) startActivity(launch)
            else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }

    private fun startListening() {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_MICROPHONE) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 501)
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 501)
            return
        }
        if (!android.speech.SpeechRecognizer.isRecognitionAvailable(this)) {
            replyAndSpeak("Is phone par speech recognition available nahi hai. Text box use karo.")
            return
        }
        try {
            recognizer?.destroy()
            recognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { runOnUiThread { status.text = "Sun raha hoon… bolo" } }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { runOnUiThread { status.text = "Command process ho rahi hai…" } }
                override fun onError(error: Int) {
                    runOnUiThread { status.text = "Voice recognition error ($error). Dobara try karo." }
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    runOnUiThread {
                        if (!text.isNullOrBlank()) {
                            input.setText(text)
                            handleCommand(text)
                        } else status.text = "Awaaz samajh nahi aayi. Dobara bolo."
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS ko command do")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            replyAndSpeak("Voice start nahi ho paayi. Phone ka microphone permission check karo.")
        }
    }

    private fun replyAndSpeak(message: String) {
        addBubble("JARVIS", message)
        speak(message)
    }

    private fun speak(message: String) {
        val short = if (message.length > 1200) message.take(1200) else message
        runOnUiThread {
            try { tts?.speak(short, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}") }
            catch (_: Exception) {}
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 501 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == 501) {
            replyAndSpeak("Microphone permission nahi mili. Voice ke liye permission allow karo ya text type karo.")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        executor.shutdownNow()
        super.onDestroy()
    }
}
