# Ultimate JARVIS Android (starter project)

Native Android Kotlin starter app for the personal Ultimate JARVIS AI backend.

## What is included
- Hindi (`hi-IN`) push-to-talk speech recognition using Android's available speech service.
- Hindi text-to-speech replies.
- Chat requests to `https://ultimate-jarvis-ai.onrender.com`.
- Session login using the backend `APP_PASSWORD`.
- Local intent shortcuts for YouTube, Chrome, Maps, browser search, and Settings.
- Confirmation before opening call/message flows.
- Basic backend health status.

## Important limitations
- This is source code, not an APK. Build it with Android Studio on a computer or another trusted Android build environment.
- The current app uses push-to-talk. It does not listen continuously in the background and does not implement a wake word. Always-on listening needs an explicit foreground service, persistent notification, battery/privacy handling, and testing on the target phone.
- Android intentionally restricts silent calls, sending messages, changing protected settings, and controlling other apps. This starter opens system apps/intents and requires user review.
- The backend chat request currently assumes `POST /api/session` accepts `{"password":"..."}` and returns a token, and `POST /api/chat` accepts `{"message":"...","history":[]}` with a Bearer token. If the current server contract differs, update `MainActivity.kt` to match it.
- Configure `GROQ_API_KEY` or `OPENAI_API_KEY` on Render for actual AI answers. Never put provider API keys in the Android app.
- Password is held in memory only and is not saved by the app.
- Backend login/API integration has not been end-to-end tested from this generated project.

## Build
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Let Gradle sync and install Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or create an APK using Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install on your own phone and grant microphone permission when prompted.
