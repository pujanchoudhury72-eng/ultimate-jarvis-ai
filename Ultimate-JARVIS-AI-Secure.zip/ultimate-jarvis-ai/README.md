# Ultimate JARVIS AI

A responsive personal AI dashboard with browser voice input/output, local chat history and tasks, a code workbench, a PWA install manifest, and a Node.js API supporting both Groq and OpenAI. API keys stay server-side. The backend requires a private `APP_PASSWORD` before issuing a short-lived HMAC-signed JWT session token using `JWT_SECRET`. Login attempts are rate-limited.

## Render deployment

Use a **new GitHub repository** for this project so the existing Nexus AI repository and services remain untouched. Upload the contents of this folder to the new repository, then in Render create a new Web Service from that repository.

- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Health check path: `/api/health`
- Plan: Free (subject to Render's current limits)

Set these environment variables in Render → Environment:

- `APP_PASSWORD`: choose a private password with at least 12 characters. Set it directly in Render; do not send it in chat or commit it to GitHub.
- `JWT_SECRET`: a new random secret with at least 32 characters. Keep it private.
- `GROQ_API_KEY`: your Groq API key.
- `OPENAI_API_KEY`: your OpenAI API key.
- `GROQ_MODEL`: optional; default `llama-3.3-70b-versatile`.
- `OPENAI_MODEL`: optional; default `gpt-4o-mini`.

The app's Settings page lets you choose Groq or OpenAI. The keys are never sent to the browser. Check `https://YOUR-RENDER-SERVICE.onrender.com/api/health` after deployment; it reports only whether keys are configured, never their values.

## Run locally

1. Install Node.js 18+.
2. Run `npm install`.
3. Set environment variables in your shell (or use a local `.env` loader you trust; `.env` is ignored by Git).
4. Run `npm start` and open `http://localhost:3000`.

## Android

This is an installable PWA, not a native APK/AAB. On Android, open the deployed HTTPS URL in Chrome, open the browser menu, and choose **Install app** or **Add to Home screen**. A native Android App Bundle requires an additional Android wrapper/build process and must be built and tested separately.

## Scope and limitations

- Chat, coding assistance and planning use the selected AI provider.
- Voice input/output depend on browser support and microphone permission.
- Chat history, preferences and tasks are stored locally in the browser and do not sync between devices.
- Web search, image/video/music generation, full Android device control, smart-home control and autonomous external actions need their own integrations. This project does not pretend those features are already connected.
- API provider usage may incur charges; hosting being free does not make the AI API free.

Never put real API keys in GitHub, frontend code, or this chat.
