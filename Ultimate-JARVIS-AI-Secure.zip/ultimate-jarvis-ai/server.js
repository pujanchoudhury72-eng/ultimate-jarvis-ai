"use strict";
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "";
const APP_PASSWORD = process.env.APP_PASSWORD || "";
const loginAttempts = new Map();
app.disable("x-powered-by");
app.use(express.json({ limit: "100kb" }));
app.use((req,res,next)=>{res.setHeader("X-Content-Type-Options","nosniff");res.setHeader("Referrer-Policy","no-referrer");res.setHeader("Permissions-Policy","microphone=(self)");next();});
app.use(express.static(path.join(__dirname,"public"),{extensions:["html"]}));
function b64(s){return Buffer.from(s).toString("base64url");}
function issueToken(){const now=Math.floor(Date.now()/1000);const h=b64(JSON.stringify({alg:"HS256",typ:"JWT"}));const p=b64(JSON.stringify({sub:"jarvis-web",iat:now,exp:now+3600}));const sig=crypto.createHmac("sha256",JWT_SECRET).update(h+"."+p).digest("base64url");return h+"."+p+"."+sig;}
function validToken(token){if(!JWT_SECRET||!token)return false;const parts=token.split(".");if(parts.length!==3)return false;let supplied;try{supplied=Buffer.from(parts[2],"base64url");}catch{return false;}const expected=crypto.createHmac("sha256",JWT_SECRET).update(parts[0]+"."+parts[1]).digest();if(supplied.length!==expected.length||!crypto.timingSafeEqual(supplied,expected))return false;try{return JSON.parse(Buffer.from(parts[1],"base64url").toString()).exp>Math.floor(Date.now()/1000);}catch{return false;}}
app.get("/api/health",(_req,res)=>res.json({status:"ok",app:"Ultimate JARVIS AI",jwtConfigured:JWT_SECRET.length>=32,passwordProtection:APP_PASSWORD.length>=12,providers:{groq:Boolean(process.env.GROQ_API_KEY),openai:Boolean(process.env.OPENAI_API_KEY)}}));
app.post("/api/session",(req,res)=>{
 const ip=req.ip||req.socket.remoteAddress||"unknown";const now=Date.now();const entry=loginAttempts.get(ip)||{count:0,until:0};
 if(entry.until>now)return res.status(429).json({error:"Too many login attempts. Wait 10 minutes and try again."});
 if(APP_PASSWORD.length<12)return res.status(503).json({error:"APP_PASSWORD is not configured. Set a strong password (12+ characters) in Render."});
 if(JWT_SECRET.length<32)return res.status(503).json({error:"JWT_SECRET is missing or too short. Set a strong random secret in Render."});
 const supplied=typeof req.body?.password==="string"?req.body.password:"";const a=Buffer.from(supplied);const b=Buffer.from(APP_PASSWORD);
 if(a.length!==b.length||!crypto.timingSafeEqual(a,b)){entry.count++;if(entry.count>=5){entry.count=0;entry.until=now+10*60*1000;}loginAttempts.set(ip,entry);return res.status(401).json({error:"Incorrect password. Try again."});}
 loginAttempts.delete(ip);res.json({token:issueToken(),expiresIn:3600});
});
app.post("/api/chat",async(req,res)=>{const auth=req.headers.authorization||"";if(!validToken(auth.startsWith("Bearer ")?auth.slice(7):""))return res.status(401).json({error:"Secure session expired. Retry your message."});
 const {message,history=[],provider="groq"}=req.body||{};if(typeof message!=="string"||!message.trim())return res.status(400).json({error:"A non-empty message is required."});if(message.length>30000)return res.status(413).json({error:"Message is too long (maximum 30,000 characters)."});
 let base,key,model;if(provider==="openai"){base="https://api.openai.com/v1";key=process.env.OPENAI_API_KEY;model=process.env.OPENAI_MODEL||"gpt-4o-mini";}else if(provider==="groq"){base="https://api.groq.com/openai/v1";key=process.env.GROQ_API_KEY;model=process.env.GROQ_MODEL||"llama-3.3-70b-versatile";}else return res.status(400).json({error:"Choose Groq or OpenAI."});
 if(!key)return res.status(503).json({error:provider.toUpperCase()+"_API_KEY is not configured in Render."});
 const safe=Array.isArray(history)?history.filter(m=>m&&["user","assistant"].includes(m.role)&&typeof m.content==="string").slice(-12).map(m=>({role:m.role,content:m.content.slice(0,12000)})):[];
 const messages=[{role:"system",content:"You are JARVIS, a precise and helpful personal AI assistant. Reply in the user's language when practical. Be honest about tool access and never claim actions you did not perform."},...safe,{role:"user",content:message.trim()}];
 const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),45000);try{const r=await fetch(base+"/chat/completions",{method:"POST",headers:{Authorization:"Bearer "+key,"Content-Type":"application/json"},body:JSON.stringify({model,messages,temperature:0.5}),signal:controller.signal});const data=await r.json().catch(()=>({}));if(!r.ok){console.error("AI provider error",r.status,JSON.stringify(data).slice(0,500));return res.status(502).json({error:(data?.error?.message||"AI provider returned HTTP "+r.status).slice(0,500)});}const reply=data?.choices?.[0]?.message?.content;if(typeof reply!=="string"||!reply.trim())return res.status(502).json({error:"AI provider returned an empty response."});res.json({reply:reply.trim(),model,provider});}catch(e){res.status(e.name==="AbortError"?504:502).json({error:e.name==="AbortError"?"AI request timed out. Try again.":"Could not reach the configured AI provider."});}finally{clearTimeout(timer);}});
app.get("*",(_req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,"0.0.0.0",()=>console.log("Ultimate JARVIS AI listening on port "+PORT));
